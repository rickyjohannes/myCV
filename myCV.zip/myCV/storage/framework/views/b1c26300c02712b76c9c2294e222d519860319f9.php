<div class="container">
    <nav class="navbar navbar-expand-md navbar-light">
        <div class="container-fluid">
          <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(url('img/logo1.png')); ?>" alt=""></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            
            <ul class="navbar-nav ml-auto">
              <!-- Authentication Links -->

              
            
              <?php if(auth()->guard()->guest()): ?>
              <?php if(Route::has('login')): ?>
              <li class="nav-item">
                <div class="row">
                  <div class="col-sm">
                              <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="<?php echo e(route('abouts')); ?>">About Me</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('resumes')); ?>">Resume</a>
                              </li>
                             
                              <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('skills')); ?>">Skill</a>
                              </li>   
                              <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('portofolios')); ?>">portofolio</a>
                              </li>  
                              <div class=" col-2 justify-content-end mt-2">
    
                                <a class="btn btn-primary" style="color:black" href="<?php echo e(route('contacts')); ?>">Contact US</a>
                              </div>                     
                  </div>
                  
                  
                </div>
              </li>
              <?php endif; ?>
              <?php else: ?>
              <li class="nav-item dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <?php echo e(Auth::user()->name); ?>

                </a>
                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <li>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                  <?php echo csrf_field(); ?>
                              </form>
                  </li>
                  
                </ul>
              </li>
             
              <?php endif; ?>
          </ul>
            
          </div>
        </div>
      </nav>
</div><?php /**PATH C:\xampp\htdocs\myCV\resources\views/components/nav.blade.php ENDPATH**/ ?>