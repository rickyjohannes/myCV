<?php $__env->startSection('title'); ?>
  Portofolio
 <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div id="fh5co-work" class="fh5co-bg-dark">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Portofolio</h2>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered animate-box">
              <thead>
                <tr class="table">
                  <th scope="col">Name</th>
                  <th scope="col">URL</th>
                  <th scope="col">Language</th>
                </tr>
              </thead>
              <tbody>
                
              </tbody>
            </table>
          </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\myCV\resources\views/portofolio.blade.php ENDPATH**/ ?>