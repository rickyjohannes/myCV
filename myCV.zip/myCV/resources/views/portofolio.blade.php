@extends('layouts.app')

@section('title')
  Portofolio
 @stop

@section('content')

<div id="fh5co-work" class="fh5co-bg-dark">
    <div class="container">
        <div class="row animate-box">
            <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                <h2>Portofolio</h2>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered animate-box">
              <thead>
                <tr class="table">
                  <th scope="col">Name</th>
                  <th scope="col">URL</th>
                  <th scope="col">Language</th>
                </tr>
              </thead>
              <tbody>
                
              </tbody>
            </table>
          </div>
        </div>
    </div>
</div>

@endsection